package com.health.medicalblue.member.dao;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import com.health.medicalblue.member.dto.MemberDTO;

@Repository
@Mapper
public interface IMemberDAO {
	//회원가입
	public int registMember(MemberDTO member);
	
	//로그인
	public MemberDTO loginMember(MemberDTO member);
}