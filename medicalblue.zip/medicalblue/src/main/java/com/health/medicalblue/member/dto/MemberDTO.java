package com.health.medicalblue.member.dto;

public class MemberDTO {
	private String memId;
	private String memPw;
	private String memName;
	private String memPhone;
	private String memMail;
	private String memIdnum;
	
	public MemberDTO() { }

	public MemberDTO(String memId, String memPw, String memName, String memPhone, String memMail, String memIdnum) {
		super();
		this.memId = memId;
		this.memPw = memPw;
		this.memName = memName;
		this.memMail = memMail;
		this.memIdnum = memIdnum;
	}

	public String getMemId() {
		return memId;
	}

	public void setMemId(String memId) {
		this.memId = memId;
	}

	public String getMemPw() {
		return memPw;
	}

	public void setMemPw(String memPw) {
		this.memPw = memPw;
	}

	public String getMemName() {
		return memName;
	}

	public void setMemName(String memName) {
		this.memName = memName;
	}
	
	public String getMemPhone() {
		return memPhone;
	}

	public void setMemPhone(String memPhone) {
		this.memPhone = memPhone;
	}

	public String getMemMail() {
		return memMail;
	}

	public void setMemMail(String memMail) {
		this.memMail = memMail;
	}

	public String getMemIdnum() {
		return memIdnum;
	}

	public void setMemIdnum(String memIdnum) {
		this.memIdnum = memIdnum;
	}

	
}