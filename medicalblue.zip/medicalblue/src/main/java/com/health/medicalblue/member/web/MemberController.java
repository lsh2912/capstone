package com.health.medicalblue.member.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.health.medicalblue.member.dto.MemberDTO;
import com.health.medicalblue.member.service.MemberService;

import jakarta.servlet.http.HttpServletRequest;

@Controller
public class MemberController {
	
	@Autowired
	MemberService memberService;
	
	//회원가입 화면 제공
	@RequestMapping("/register")
	public String regist() {
		
		return "register";
	}
	
	//회원가입 진행
	@RequestMapping("/registDo")
	public String registDo(HttpServletRequest request) {
		
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		String name = request.getParameter("name");
		String phone = request.getParameter("phone");
		String email = request.getParameter("email");
		String idnum = request.getParameter("idnum");
		
		System.out.println("id = " + id);
		System.out.println("pw = " + pw);
		System.out.println("name = " + name);
		System.out.println("email = " + email);
		System.out.println("idnum = " + idnum);
		
		MemberDTO member = new MemberDTO(id, pw, name, phone, email, idnum);
		try {
			memberService.registMember(member);
		} catch (Exception e) {
			e.printStackTrace();
			return "404";
		}
		return "redirect:/";
		
	}
	
	//로그인
	@RequestMapping("/login")
	public String login() {
			return "login";
	}
	
	//로그인 진행
	@RequestMapping("/loginDo")
	public String loginDo(MemberDTO member) throws Exception {
		
		System.out.println(member);
				
		MemberDTO login = memberService.loginMember(member);
		System.out.println(login);
		return "redirect:/";
		
	}
}
