package com.health.medicalblue;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MedicalblueApplicationTests {

	@Test
	void contextLoads() {
	}

}
